#include <complex.h>
#include <fftw3.h>
#include <iostream>
#include <fstream>
#include <cmath>
#include <stdlib.h> //command line parsing
#include <assert.h> //assert when file could not open
#include <vector>


using namespace std;


template <typename T>
std::string to_string_p(const T a_value, const int n = 15){
    std::ostringstream out;
    out.precision(n);
    out << std::fixed << a_value;
    return out.str();
}


int main (int argc, const char * argv[]) {
    
    fftw_complex *in, *out;
    fftw_plan p;

    const int N = 6000;
    const double length = 10;
    const int parm_num = atoi(argv[1]); //number of parameters
    const int order = atoi(argv[2]); //order of differentiation //Hardy basis order
    const long double eta = atof(argv[3]); //eta
    std::string cofile = argv[4]; //coefficient file
    std::string parmfile = argv[5]; //parameter file
    std::string normfile = argv[6]; //sobolev norm output file
    std::string spectral = argv[7]; //spectral output file
    std::ifstream ifile (cofile);
    assert (ifile);
    std::ifstream ifilep (parmfile);
    assert (ifilep);
    std::ofstream ofile (normfile);
    assert (ofile);
    std::ofstream sfile (spectral);
    assert (sfile);
    
    in = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);
    out = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);
    p = fftw_plan_dft_1d(N, in, out, FFTW_FORWARD, FFTW_ESTIMATE);
    
    vector <complex<long double> > par1 (parm_num);
    vector <complex<long double> > par2 (parm_num);
    for (int i = 0; i < parm_num; i++) {
        long double re1, im1, re2, im2;
        ifilep >> re1 >> im1 >> re2 >> im2;
        par1[i] = complex<long double> {re1, im1};
        par2[i] = complex<long double> {re2, im2};
    }
    vector <complex<long double> > zpow (parm_num);
    complex<long double> One = complex<long double>{1, 0};
    complex<long double> Im =  complex<long double>{0, 1};
    complex<long double> sqrt_pi  =  complex<long double>{sqrt(M_PI), 0};
    for (int i = 0; i < N; i++) {
        long double freq, a_re, a_im, b_re, b_im, c_re, c_im, d_re, d_im;
        ifile >> freq >> a_re >> a_im >> b_re >> b_im >> c_re >> c_im >> d_re >> d_im;
        complex<long double> z {freq, eta};
        complex<long double> a {a_re, a_im};
        complex<long double> b {b_re, b_im};
        complex<long double> c {c_re, c_im};
        complex<long double> d {d_re, d_im};
        complex<long double> z1 = (z - Im) / (z + Im);
        
        complex<long double> poly1;
        complex<long double> poly2;
        complex<long double> poly;
        for (int j = 0; j < parm_num; j++) {
            zpow[j] = pow(z1, j);
            poly1 += par1[j] * (zpow[j] * (One - z1) / sqrt_pi);
            poly2 += par2[j] * std::conj(zpow[j] * (One - z1) / sqrt_pi);
        }
        poly = poly1 + poly2;

        complex<long double> theta = (a * poly + b) / (c * poly + d);
        long double real = 1 / M_PI * std::imag (Im * ((One + theta) / (One - theta)));
        in[i][0] = real;
        in[i][1] = 0;
        sfile << freq << " "<< real << endl;
    }

    fftw_execute(p);

    long double sum_out1 = 0;
    for (int i = 0; i < N; i++) {
	    sum_out1 += in[i][0];
    }
    sum_out1 = pow(1 - sum_out1*(2*length)/double(N), 2);
    
    long double sum_out2 = 0;
    if (N % 2 == 0) {
        for (int i = 0; i < N/2; i++) {
            sum_out2 += (pow(2*M_PI*i/(2*length), 4) * (pow(out[i][0], 2) + pow(out[i][1], 2)));
        }
        for (int i = N/2 + 1; i < N; i++) {
            sum_out2 += (pow(2*M_PI*(i - N)/(2*length), 4) * (pow(out[i][0], 2) + pow(out[i][1], 2)));
        }
    }
    else {
        for (int i = 0; i < N; i++) {
	    sum_out2 += (pow(2*M_PI*std::min(i, N-i)/(2*length), 4) * (pow(out[i][0], 2) + pow(out[i][1], 2)));
        }
    }
    sum_out2 = sum_out2*(2*length)/double(N)/double(N);

    long double sum_out = sum_out1 + 0.00001 * sum_out2;
    ofile << to_string_p(sum_out, 35) << endl;

    ifile.close();
    ifilep.close();
    ofile.close();

    fftw_destroy_plan(p);
    fftw_free(in); fftw_free(out);

}
