#include "schur.h"
#include "mpreal.h"

using namespace mpfr;

int main (int argc, char * argv[]) {
  std::string ifile, ofile, coefile;
  int imag_num;
  //prompt user for input parameters
  std::cin >> ifile >> imag_num >> ofile >> coefile;
  //set calculation precision
  mpreal::set_default_prec(1024);
  //begin evaluation
  Schur<mpreal> NG(ifile, imag_num, ofile);
  NG.evaluation(coefile);
  return 0;
}