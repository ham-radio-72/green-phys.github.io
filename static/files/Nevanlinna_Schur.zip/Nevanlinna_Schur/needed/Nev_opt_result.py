import os
import numpy as np

# ----------------------------------------------------------------------
def write_extract():
    script = """#!/bin/bash
#SBATCH --job-name="result"
#SBATCH --output="job.%j.%N.out"
#SBATCH --partition=super,batch,debug
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH -t 2:00:00

rm -rf opt_result
mkdir opt_result
cd opt_result
cp ../dakota/screen .
cp ../dakota/process .
cp ../dakota/optimization_values.dat .
tail -2000 optimization_values.dat > best_params
tail -n +2 best_params > best_params_1
awk {} best_params_1 | sort -gr | cut -f2- -d' ' > best_params_2
tail -1 best_params_2 > best_params_3
sed -ri 's/.* NO_ID//' best_params_3
awk {} best_params_3 > opt_params
rm best_params*
""".format("'{print $NF,$0}'", "'{$NF=\"\"}1'")
    fd = open('job_extract', 'w')
    fd.write(script)
    fd.close()


# ----------------------------------------------------------------------
def write_jobscript(exe_path, basis, eta):
    script = """#!/bin/bash
#SBATCH --job-name="sobolev"
#SBATCH --output="job.%j.%N.out"
#SBATCH --partition=super,batch,debug
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --export=ALL
#SBATCH -t 2:00:00
#SBATCH --exclusive

"""
    fd = open('job', 'w')
    fd.write(script)

    fd.write(
        '{} {} 0 {} coeff opt_result/opt_params opt_result/sobolev.txt Aopt.txt'.format(exe_path, basis, eta))

    fd.close()


# ----------------------------------------------------------------------
if __name__ == '__main__':
	
    exe = '/pauli-storage/jianif/scripts/Nevanlinna_truncation/build/sobolev'
    basis = 15
    eta = 0.001

    write_extract()
    write_jobscript(exe, basis, eta)
    os.system('sbatch job_extract')



