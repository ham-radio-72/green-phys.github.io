import os
import sys
import glob
import itertools
import numpy as np
import math

# ----------------------------------------------------------------------
def write_dakota_input():

    f1 = open("./dakota/dakota_pstudy.in", "w")

    str1 = """# DAKOTA INPUT FILE for Hardy Basis Function Optimization

environment
  tabular_data
    tabular_data_file = 'optimization_values.dat'

method
  conmin_frcg
    convergence_tolerance = 1e-10
    max_iterations = 20000
    max_function_evaluations = 200000
  output quiet


model
  single


variables
continuous_design = """
    f1.write(str1)

    f1.write(str(4 * basis) + "\ninitial_point\n")
    for k in range(4 * basis):
        f1.write("0\n")
    f1.write("\ndescriptors\n")
    for k in range(basis):
        f1.write("'y" + str(k) + "_re1'\n")
        f1.write("'y" + str(k) + "_im1'\n")
        f1.write("'y" + str(k) + "_re2'\n")
        f1.write("'y" + str(k) + "_im2'\n")
    f1.write("\nscale_types\n")
    for k in range(4 * basis):
        f1.write("'none'\n")

    str2 = """
interface,
  analysis_driver = 'driver'
    fork
    parameters_file = 'params.in'
    results_file = 'results.out'
    file_tag
    file_save

responses,
  objective_functions = 1
  descriptors = 'sobolev'
  numerical_gradients
    forward
  no_hessians
"""
    f1.write(str2)
    f1.close()

# ----------------------------------------------------------------------
def write_drive(exe_path, coeff_file, eta):

    f2 = open("./dakota/driver", "w")

    str3 = """#!/bin/sh

# script to create working directory, populate, and run text_book in serial.
# NOTE: if a real application is substituted for text_book it MUST BE SERIAL!

#-----------------------------------
# CREATE TEMPORARY WORKING DIRECTORY
#
# This prevents file trampling when running concurrent jobs.
#-----------------------------------

num=$(echo $1 | awk -F. '{print $NF}')
topdir=`pwd`
workdir=$topdir/workdir.$num

mkdir workdir.$num
cp $topdir/$1 $workdir/dakota_vars
cd $workdir


# -------------------------
# INPUT FILE PRE-PROCESSING
# -------------------------

# This demo does not need file pre-processing, but normally (see
# below) APREPRO or DPREPRO is used to "cut-and-paste" data from the
# params.in.# file written by DAKOTA into a template input file for
# the user's simulation code.

# aprepro run6crh_rigid_template.i temp_rigid.new
# grep -vi aprepro temp_rigid.new > run6crh_rigid.i

# dprepro $1 application_input.template application.in 

# For this example we just prepare the application input by copying
# the parameters:
#cp dakota_vars application.in

dprepro dakota_vars ../params.template params.txt 
"""
    f2.write(str3)

    f2.write('{} {} 0 {} ../../{} ./params.txt ./sobolev.txt ./A.txt'.format(exe_path, basis, eta, coeff_file))

    str4 = """
# ---------------------------
# OUTPUT FILE POST PROCESSING
# ---------------------------

cp sobolev.txt ../$2

cd ..

# -------------
# CLEANUP
# -------------

# uncomment to cleanup work directories as evaluations progress
rm -rf ./workdir.$num"""

    f2.write(str4)
    f2.close()

# ----------------------------------------------------------------------
def write_param_template():

    f3 = open("./dakota/params.template", "w")
    for k in range(basis):
        f3.write("{y" + str(k) + "_re1}\n")
        f3.write("{y" + str(k) + "_im1}\n")
        f3.write("{y" + str(k) + "_re2}\n")
        f3.write("{y" + str(k) + "_im2}\n")
    f3.close()

# ----------------------------------------------------------------------
def write_job_file(number, n_nodes, n_cores, wall_time, n_tasks):

    script = """#!/bin/bash
#SBATCH --job-name="hardy"
#SBATCH --partition=super,batch,debug
#SBATCH --nodes=%i
#SBATCH --ntasks-per-node=%i
#SBATCH --export=ALL
#SBATCH -t %i:00:00
#SBATCH --exclusive

module load dakota/6.14.0

mpirun -np %i dakota -i ./dakota_pstudy.in -o screen > process

    """ % (n_nodes, n_cores, wall_time, n_tasks)

    fd = open('./dakota/jobopt', 'w')
    fd.write(script)
    fd.close()


# ----------------------------------------------------------------------
if __name__ == '__main__':

    submit = 1

    basis = 15
    eta = 0.001 # should be the same number as in Nev
    n_tasks = 2 * 2 * basis + 1

    n_nodes = 1
    n_cores = math.ceil(n_tasks / n_nodes)
    wall_time = 64

    exe = '/pauli-storage/jianif/scripts/Nevanlinna_truncation/build/sobolev'
    
    coeff_file = "coeff"
    os.system('rm -rf dakota')
    os.mkdir('dakota')
    write_dakota_input()
    write_drive(exe, coeff_file, eta)
    write_param_template()
    write_job_file(0, n_nodes, n_cores, wall_time, n_tasks)

    if submit:
        os.chdir('dakota')
        os.system('chmod ugo+rwx driver')
        os.system('sbatch jobopt')

        current_path = os.getcwd()
        parent_path = os.path.join(current_path, os.pardir)
        os.chdir(parent_path)


