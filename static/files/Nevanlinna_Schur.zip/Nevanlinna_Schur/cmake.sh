cmake \
-DFFTW3_DIR=/opt/ohpc/pub/libs/gcc/7.3.0/fftw/3.3.8 ..
